package com.rwn.rwnstudy.activities;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.rwn.rwnstudy.R;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.rwn.rwnstudy.activities.UploadDocumentActivity.REQUEST_IMAGE_CAPTURE;

/**
 * A simple {@link Fragment} subclass.
 */


public class UploadFragment extends Fragment {
    static  private  final  String TAG="UploadFragment";

    public UploadFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        Log.d(TAG, "onCreate: created on create of upload fragment");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment



        Log.d(TAG, "onCreateView: created on create of upload fragment");


        return inflater.inflate(R.layout.fragment_upload, container, false);
    }


}

