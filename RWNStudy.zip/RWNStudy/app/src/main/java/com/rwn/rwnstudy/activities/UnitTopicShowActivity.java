package com.rwn.rwnstudy.activities;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.rwn.rwnstudy.R;
import com.rwn.rwnstudy.utilities.ConstantForApp;
import com.rwn.rwnstudy.utilities.DocumentAdapter;
import com.rwn.rwnstudy.utilities.DocumentGetterSetter;
import com.rwn.rwnstudy.utilities.UserGetterAndSetter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

//import com.rwn.rwnstudy.utilities.Constant;

public class UnitTopicShowActivity extends AppCompatActivity implements RewardedVideoAdListener {
    private RecyclerView recyclerViewUnitTopic;
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private String CURRENT_USER,UserId;
    private  String UnitName,SubjectName,Section;
    final  static  String TAG= "RWNStudy";
    private TextView textView;
    private  DocumentAdapter documentAdapter;
    private final List<DocumentGetterSetter> documentGetterSetterslist = new ArrayList<>();
    LinearLayoutManager linearLayoutManager;
    String PersonalDocument= null;

    AdView mAdView;

    public static RewardedVideoAd mRewardedVideoAd;

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_topic_show);




        MobileAds.initialize(this, "ca-app-pub-3419747624746104~4537061916");



        getpendingIntent();
        actionBarDesinging();
        dataBaseSetUp();
        testing();

        mAdView = findViewById(R.id.adView);

        addPlacement();

        mRewardedVideoAd.setRewardedVideoAdListener(this);
        loadRewardedVideoAd();

    }
    static public void loadRewardedVideoAd() {
        mRewardedVideoAd.loadAd("ca-app-pub-3419747624746104/1105551893",
                new AdRequest.Builder().build());
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void addPlacement() {
        MobileAds.initialize(this,getString(R.string.banner_unit_topic_footer));
        AdView adView = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            adView = new AdView(Objects.requireNonNull(UnitTopicShowActivity.this));
            adView.setAdSize(AdSize.BANNER);
            adView.setAdUnitId(getString(R.string.banner_unit_topic_footer));


            mAdView = findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        }
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                Log.d("ADMOBTESTING", "onAdLoaded:  UnitTopicShowActivity : load ");
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {

                Log.d("ADMOBTESTING", "onAdLoaded: UnitTopicShowActivity : failed "+ errorCode);
            }

            @Override
            public void onAdOpened() {

                Log.d("ADMOBTESTING", "onAdLoaded:  UnitTopicShowActivity : opened ");
            }

            @Override
            public void onAdLeftApplication() {

                Log.d("ADMOBTESTING", "onAdLoaded:  UnitTopicShowActivity : ad left application ");
            }

            @Override
            public void onAdClosed() {

                Log.d("ADMOBTESTING", "onAdLoaded:  UnitTopicShowActivity : ad Closed ");
            }
        });

    }
    private void getpendingIntent() {
        textView=  findViewById(R.id.textview_units);
        Intent intent = getIntent();
        SubjectName= intent.getStringExtra("SubjectKeyWithSection");
        PersonalDocument= intent.getStringExtra("PersonalDocument");
        UnitName=intent.getStringExtra("Unit");
        UserId=intent.getStringExtra("userId");



    }

    private  void testing(){


        if(PersonalDocument != null)
        {
            Query query =databaseReference.child("Users").child(CURRENT_USER);

            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    String node;
                    UserGetterAndSetter userGetterAndSetter  = dataSnapshot.getValue(UserGetterAndSetter.class);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        String  userType= Objects.requireNonNull(userGetterAndSetter).getUserType();
                      DatabaseReference dommmm ;
                        if(userType.equals(ConstantForApp.TEACHER)){
                            node = "TeacherUplodedDocument";
                          dommmm=  databaseReference.child(node).child(SubjectName).child(UnitName);

                        }
                        else{
                            node = "StudentUplodedDocument";
                           dommmm= databaseReference.child(node).child(SubjectName).child(UnitName).child(CURRENT_USER);

                        }

                        if(dommmm != null)
                        dommmm.addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                                if (dataSnapshot.exists()) {
                                    DocumentGetterSetter documentGetterSetter = dataSnapshot.getValue(DocumentGetterSetter.class);
                                    documentGetterSetterslist.add(documentGetterSetter);
                                    documentAdapter.notifyDataSetChanged();
                                }
                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    DocumentGetterSetter documentGetterSetter = dataSnapshot.getValue(DocumentGetterSetter.class);
                                    documentGetterSetterslist.remove(documentGetterSetter);


                                    documentAdapter.notifyDataSetChanged();
                                }
                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
        else{
            databaseReference.child("TeacherUplodedDocument").child(SubjectName).child(UnitName)
                    .addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            if (dataSnapshot.exists()) {
                                DocumentGetterSetter documentGetterSetter = dataSnapshot.getValue(DocumentGetterSetter.class);
                                documentGetterSetterslist.add(documentGetterSetter);
                                documentAdapter.notifyDataSetChanged();
                            }
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists()) {
                                DocumentGetterSetter documentGetterSetter = dataSnapshot.getValue(DocumentGetterSetter.class);
                                documentGetterSetterslist.remove(documentGetterSetter);
                                documentAdapter.notifyDataSetChanged();
                            }
                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

        }
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void actionBarDesinging() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(getSupportActionBar()).setTitle("Topics of Unit");
        }
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        viewIntializing();

    }

    private void viewIntializing() {

        recyclerViewUnitTopic = findViewById(R.id.recyclerView_topic);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(UnitTopicShowActivity.this);
        recyclerViewUnitTopic.setLayoutManager(linearLayoutManager);
        documentAdapter = new DocumentAdapter(UnitTopicShowActivity.this,documentGetterSetterslist,SubjectName,UnitName);
        recyclerViewUnitTopic.setAdapter(documentAdapter);

    }
    private void dataBaseSetUp() {
        mAuth = FirebaseAuth.getInstance();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            CURRENT_USER  = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        }
        if(UserId != null){
            CURRENT_USER = UserId;
        }
        databaseReference = FirebaseDatabase.getInstance().getReference();



    }


    @Override
    public void onRewardedVideoAdLoaded(){
       // Toast.makeText(UnitTopicShowActivity.this, "loaded", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRewardedVideoAdOpened() {

    }

    @Override
    public void onRewardedVideoStarted() {
        loadRewardedVideoAd();
    }

    @Override
    public void onRewardedVideoAdClosed() {

    }

    @Override
    public void onRewarded(RewardItem rewardItem) {

        DocumentAdapter.downloadFile(DocumentAdapter.filename, DocumentAdapter.documentGetterSetter1.getDocumentLink(), ".pdf");
        Toast.makeText(UnitTopicShowActivity.this, "Downloading Start after downloading Docs will be auto opened", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onRewardedVideoAdLeftApplication() {

    }

    @Override
    public void onRewardedVideoAdFailedToLoad(int i) {

       // Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();

        Log.d("bdejd", "onRewardedVideoAdFailedToLoad: "+ i);

    }

    @Override
    public void onRewardedVideoCompleted() {

    }

    @Override
    protected void onPause() {
        super.onPause();
        mRewardedVideoAd.pause(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mRewardedVideoAd.resume(this);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mRewardedVideoAd.destroy(this);
    }
}
