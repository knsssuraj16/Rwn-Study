package com.rwn.rwnstudy.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.rwn.rwnstudy.R;
//import com.rwn.rwnstudy.utilities.Constant;

import java.util.Objects;

public class ForgetPasswordResertActivity extends AppCompatActivity {

    EditText editTextEmail;
    Button button;
    FirebaseAuth mAuth;
    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password_resert);

        mAuth= FirebaseAuth.getInstance();


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(getSupportActionBar()).setTitle("Password Reset");

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        user = getIntent().getStringExtra("Email");
        button= findViewById(R.id.button_send_reset_link);
        editTextEmail= findViewById(R.id.editText_email);

        editTextEmail.setText(user);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isOnline()) {
                    String userEmail = editTextEmail.getText().toString();
                    if (TextUtils.isEmpty(userEmail)) {
                        Toast.makeText(ForgetPasswordResertActivity.this, "Please Enter email id", Toast.LENGTH_SHORT).show();

                    } else {
                        mAuth.sendPasswordResetEmail(userEmail).addOnCompleteListener(new OnCompleteListener <Void>() {
                            @SuppressLint("NewApi")
                            @Override
                            public void onComplete(@NonNull Task <Void> task) {

                                if (task.isSuccessful()) {
                                    finish();
                                    Toast.makeText(ForgetPasswordResertActivity.this, "Please Check your Mail id,\n for reset password", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(ForgetPasswordResertActivity.this, "Error Occurred :" + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }

                        });
                    }
                }else{
                    Toast.makeText(ForgetPasswordResertActivity.this, "No Internet Connection Found", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
}
