package com.rwn.rwnstudy.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.rwn.rwnstudy.R;
import com.rwn.rwnstudy.utilities.ConstantForApp;

import java.util.Objects;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {


    // UI references.
    private String user;
    private AutoCompleteTextView mEmailView;
    private EditText mPasswordView;
    private TextView textViewRegister, textViewForget;

    private Button mEmailSignInButton;
    private ProgressDialog progressDialog;
    private FirebaseAuth mAuth;
    private boolean emailAddressChecker;
    private DatabaseReference databaseReferenceUserRef;
    int a = 0;
    String usertype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        userIdentificatioTeacherOrStudent();

        viewIntialization();

        buttonClickAction();



    }

    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences sharedPref = LoginActivity.this.getPreferences(Context.MODE_PRIVATE);

        String UserChecking = sharedPref.getString("USER", "");
        if (UserChecking.equals(user)) {
            String email = sharedPref.getString("TEmail_ID", "");
            String pass = sharedPref.getString("TPassword", "");
            mEmailView.setText(email);
            mPasswordView.setText(pass);
        } else if (UserChecking.equals(ConstantForApp.STUDENT)) {
            String email = sharedPref.getString("SEmail_ID", "");
            String pass = sharedPref.getString("SPassword", "");
            mEmailView.setText(email);
            mPasswordView.setText(pass);
        }

    }

    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }

    private void buttonClickAction() {

            mEmailSignInButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {

                    if(isOnline())  {
                    validation();
                    }else{
                        Toast.makeText(LoginActivity.this, "No Internet Connection found", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            textViewRegister.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                    intent.putExtra(ConstantForApp.USER, user);
                    startActivity(intent);
                    finish();
                }
            });
            textViewForget.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(LoginActivity.this, ForgetPasswordResertActivity.class);
                    intent.putExtra("Email", mEmailView.getText());
                    startActivity(intent);
                }
            });

    }

    private void validation() {
        String email = mEmailView.getText().toString().trim();
        String password = mPasswordView.getText().toString().trim();


        if (password.isEmpty()) {
            mPasswordView.setError("Field must be Fill.");
            mPasswordView.requestFocus();
        } else if (!(Patterns.EMAIL_ADDRESS.matcher(email).matches())) {
            mEmailView.setError("Enter Valid Mail");
            mEmailView.requestFocus();
        } else {
            progressDialog.setTitle("Please Wait");
            progressDialog.setMessage("We Check Your Credits");
            progressDialog.setCancelable(false);
            progressDialog.show();
            singInfrommailIdandPassword(email, password);
        }
    }

    private void singInfrommailIdandPassword(final String email, final String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener <AuthResult>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onComplete(@NonNull Task <AuthResult> task) {
                        if (task.isSuccessful()) {



                            final String CURRENT_USER_ID = mAuth.getCurrentUser().getUid();


                            databaseReferenceUserRef = FirebaseDatabase.getInstance().getReference().child(getString(R.string.datbase_user_node));
                            final DatabaseReference databaseReferenceUserRefernce = FirebaseDatabase.getInstance().getReference().child(getString(R.string.datbase_user_node)).child(CURRENT_USER_ID);

                            databaseReferenceUserRefernce.child("userType").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                                 if(dataSnapshot.exists()) {
                                     usertype = dataSnapshot.getValue().toString();
                                 }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });

                            databaseReferenceUserRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                                    if (usertype.equals(user)) {

                                        if (!dataSnapshot.hasChild(CURRENT_USER_ID) && !dataSnapshot.child(CURRENT_USER_ID).hasChild(getString(R.string.user_profile_image))) {

                                            if (a == 0) {

                                                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
                                                finish();
                                                progressDialog.dismiss();
                                                a++;
                                            }
                                        } else {
                                            if (a == 0) {

                                                String Device_token= FirebaseInstanceId.getInstance().getToken();

                                                databaseReferenceUserRefernce.child("deviceToken").setValue(Device_token).addOnCompleteListener(new OnCompleteListener <Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task <Void> task) {
                                                        if(task.isSuccessful()){
                                                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                                            saveSharedPrefrence();
                                                            finish();
                                                            progressDialog.dismiss();
                                                            a++;
                                                        }
                                                    }
                                                });

                                            }
                                        }
                                    } else {
                                        progressDialog.dismiss();
                                        Toast.makeText(LoginActivity.this, "Account not found in " + user + "Directory", Toast.LENGTH_SHORT).show();
                                        mAuth.signOut();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    String s = databaseError.getMessage();
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, s, Toast.LENGTH_SHORT).show();
                                }
                            });

                        } else {



                            String errorCode = ((FirebaseAuthException) Objects.requireNonNull(task.getException())).getErrorCode();

                            switch (errorCode) {

                                case "ERROR_INVALID_CUSTOM_TOKEN":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The custom token format is incorrect. Please check the documentation.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_CUSTOM_TOKEN_MISMATCH":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The custom token corresponds to a different audience.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_INVALID_CREDENTIAL":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The supplied auth credential is malformed or has expired.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_INVALID_EMAIL":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The email address is invalid.", Toast.LENGTH_LONG).show();

                                    break;

                                case "ERROR_WRONG_PASSWORD":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The password is invalid.", Toast.LENGTH_LONG).show();

                                    break;

                                case "ERROR_USER_MISMATCH":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The supplied credentials do not correspond to the previously signed in user.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_REQUIRES_RECENT_LOGIN":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "This operation is sensitive and requires recent authentication. Log in again before retrying this request.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_EMAIL_ALREADY_IN_USE":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The email address is already in use by another account.   ", Toast.LENGTH_LONG).show();

                                    break;

                                case "ERROR_CREDENTIAL_ALREADY_IN_USE":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "This credential is already associated with a different user account.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_USER_DISABLED":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The user account has been disabled by an administrator.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_USER_TOKEN_EXPIRED":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The user\\'s credential is no longer valid. The user must sign in again.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_USER_NOT_FOUND":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "There is no user record.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_INVALID_USER_TOKEN":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The user\\'s credential is no longer valid. The user must sign in again.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_OPERATION_NOT_ALLOWED":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "This operation is not allowed. You must enable this service in the console.", Toast.LENGTH_LONG).show();
                                    break;

                                case "ERROR_WEAK_PASSWORD":
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "The given password is invalid.", Toast.LENGTH_LONG).show();
                                    break;
                            }
                        }


                    }
                });
    }

    private void saveSharedPrefrence() {


        SharedPreferences sharedPreferences = getSharedPreferences("logindetail",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        editor.putString("Login","AlreadyLogin");
        editor.apply();

    }


    private void viewIntialization() {

        // Set up the login form.
        mEmailView = (AutoCompleteTextView) findViewById(R.id.editText_email);
        textViewRegister = findViewById(R.id.textView_register);
        mEmailSignInButton = (Button) findViewById(R.id.email_sign_in_button);
        mPasswordView = (EditText) findViewById(R.id.editText_password);
        textViewForget = findViewById(R.id.textView_forgotPassword);

        progressDialog = new ProgressDialog(this);

        mAuth = FirebaseAuth.getInstance();
    }

//    private void populateAutoComplete() {
//        if (!mayRequestContacts()) {
//            return;
//        }
//
//        getLoaderManager().initLoader(0, null, this);
//    }

//    private boolean mayRequestContacts() {
//        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
//            return true;
//        }
//        if (checkSelfPermission(READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
//            return true;
//        }
//        if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
//            Snackbar.make(mEmailView, R.string.permission_rationale, Snackbar.LENGTH_INDEFINITE)
//                    .setAction(android.R.string.ok, new View.OnClickListener() {
//                        @Override
//                        @TargetApi(Build.VERSION_CODES.M)
//                        public void onClick(View v) {
//                            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
//                        }
//                    });
//        } else {
//            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
//        }
//        return false;
//    }

    /**
     * Callback received when a permissions request has been completed.
     * //
     */
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
//                                           @NonNull int[] grantResults) {
//        if (requestCode == REQUEST_READ_CONTACTS) {
//            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                populateAutoComplete();
//            }
//        }
//    }

//
//    @Override
//    public Loader <Cursor> onCreateLoader(int i, Bundle bundle) {
//        return new CursorLoader(this,
//                // Retrieve data rows for the device user's 'profile' contact.
//                Uri.withAppendedPath(ContactsContract.Profile.CONTENT_URI,
//                        ContactsContract.Contacts.Data.CONTENT_DIRECTORY), ProfileQuery.PROJECTION,
//
//                // Select only email addresses.
//                ContactsContract.Contacts.Data.MIMETYPE +
//                        " = ?", new String[]{ContactsContract.CommonDataKinds.Email
//                .CONTENT_ITEM_TYPE},
//
//                // Show primary email addresses first. Note that there won't be
//                // a primary email address if the user hasn't specified one.
//                ContactsContract.Contacts.Data.IS_PRIMARY + " DESC");
//    }
//
//    @Override
//    public void onLoadFinished(Loader <Cursor> cursorLoader, Cursor cursor) {
//        List <String> emails = new ArrayList <>();
//        cursor.moveToFirst();
//        while (!cursor.isAfterLast()) {
//            emails.add(cursor.getString(ProfileQuery.ADDRESS));
//            cursor.moveToNext();
//        }
//
//        addEmailsToAutoComplete(emails);
//    }
//
//    @Override
//    public void onLoaderReset(Loader <Cursor> cursorLoader) {
//
//    }
//
//    private void addEmailsToAutoComplete(List <String> emailAddressCollection) {
//        //Create adapter to tell the AutoCompleteTextView what to show in its dropdown list.
//        ArrayAdapter <String> adapter =
//                new ArrayAdapter <>(LoginActivity.this,
//                        android.R.layout.simple_dropdown_item_1line, emailAddressCollection);
//
//        mEmailView.setAdapter(adapter);
//    }
//
//
//    private interface ProfileQuery {
//        String[] PROJECTION = {
//                ContactsContract.CommonDataKinds.Email.ADDRESS,
//                ContactsContract.CommonDataKinds.Email.IS_PRIMARY,
//        };
//
//        int ADDRESS = 0;
//        int IS_PRIMARY = 1;
//    }
    private void userIdentificatioTeacherOrStudent() {

        user = getIntent().getStringExtra(ConstantForApp.USER);



    }
}


